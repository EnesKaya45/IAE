print("Hello Turkey!")
