while True:
	pass
print("Hello World!")
